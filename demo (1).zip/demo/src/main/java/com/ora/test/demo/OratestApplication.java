package com.ora.test.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OratestApplication {

	public static void main(String[] args) {
		SpringApplication.run(OratestApplication.class, args);
	}

}
