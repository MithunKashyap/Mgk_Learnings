package com.ora.test.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OratestApplicationTests {

	@Test
	void contextLoads() {
	}

}
