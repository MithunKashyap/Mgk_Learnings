package com.ora.test.wartest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WartestApplicationTests {

	@Test
	void contextLoads() {
	}

}
