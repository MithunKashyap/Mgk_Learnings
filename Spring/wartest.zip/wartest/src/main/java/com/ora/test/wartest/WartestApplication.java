package com.ora.test.wartest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WartestApplication {

	public static void main(String[] args) {
		SpringApplication.run(WartestApplication.class, args);
	}

}
