package com.ora.testone.testwarone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestwaroneApplicationTests {

	@Test
	void contextLoads() {
	}

}
