package com.ora.test.testwar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestwarApplicationTests {

	@Test
	void contextLoads() {
	}

}
